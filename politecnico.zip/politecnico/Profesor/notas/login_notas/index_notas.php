<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Situación Académica</title>
<link rel="icon" href="../../../politecnico.ico">
<link rel="stylesheet" href="estilos_notas.css">
</head>
<body>

<nav class="navbar">
  <div class="dropdown">
    <button class="dropbtn">Carreras</button>
    <div class="dropdown-content">
      <a href="#">Enfermería</a>
      <a href="#">Automatización y Robótica</a>
      <a href="#">Comercialización y Marketing</a>
      <a href="#">Acompañamiento Terapéutico</a>
    </div>
  </div> 
  <a href="../../" class="btn-asistencia">Sistema de asistencia</a>
</nav>

<script src="script.js"></script>
</body>
</html>